<!DOCTYPE html>
<html>
<head>
  <title> Sign Up Initiate</title>
  <link rel="stylesheet" href="../css/initiate.css">
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
  
  
</head>

<body>
  <div class="back-body" ></div>
    <div class="overlay-body" ></div>

        <div class="home-btn">
            <img class="home-img" src="../img/home.png" alt="">
        <a class="home-text" href="#">HOME</a>
        </div>

        <div class="back-btn">
          <img class="arrow-img" src="../img/arrow.png" alt="">
      <a class="back-text" href="../view-hotel/hotelLogin.php">BACK TO LOGIN</a>
      </div>


     
  <div class="body-contents">
      <div class="left1">
        <a href="./sign.php"><button class="btns" >TOURIST</button></a>
        </div>

       <div class="right1">
        <a href="../view-entrepreneur/signup.php"><button class="btns" >ENTREPRENEUR</button></a>
       </div>

    

   
      <div class="left2">
      <a href="../view-hotel/hotelSignup.php"><button class="btns" >HOTEL</button></a>
      </div>

      <div class="right2">
      <button class="btns" >TOUR GUIDE</button>
      </div>
      
      <a class="visit-text" href="#">#VISITSRILANKA</a>       
  </div>

    

   

 

        

    
</body>
</html>