<!DOCTYPE html>
<html>
<head>
  <title> User Profile</title>
  <link rel="stylesheet" href="../css/profile.css">
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
</head>

<body>


    <div class="navbar">
        
        <ul>
          <img src="../img/logo.png" alt=" logo" style="width:40px;height:40px; margin-left: 20px;" >
          <li style="float:right"><a  href="#home">Home</a></li>
          <li style="float:right"><a  href="#contactus">Contact Us</a></li>
          <li style="float:right"><a href="#about">About</a></li>
        </ul>
      </div>
      <div class="home-btn">
        <a class="home-text" href="../api/logout.php">Log Out</a>
        </div>

      <div class="heading">
        <h2 style="color:white"><b>MY  PROFILE</b></h2>
        </div>

        <div class="tab" >
            <div class="centered">
                <img src="../img/lithu.png" alt="lithu">
                <h2><b>Lithurshika Sritharakanthan</b></h2>
                <p><b>@lithusri7</b></p>
              </div>

            <div class="vl">
             <div class="ldetails"> 
                <p>E-mail</p> 
                <p>lithurshikasri777@gmail.com</p><br>
                <p>Phone Number</p> 
                <p>+94 774193765</p><br>
                <p>Address</p> 
                <p>No 423, Main Street, Navatkudah,Batticaloa</p><br>
               
             </div>
             <div class="rdetails"> 
                <p>Languages</p> 
                <p>Tamil, English, Sinhala, Hindi</p><br>
                <p>Date of Birth</p> 
                <p>25.07.2000</p><br>
                <p>Country of Origin</p> 
                <p>Sri Lanka</p><br>
            </div>
        </div>

        <div class="orl">
            <p><b>ORDERED LIST</b></p>
        </div>

        <div class="wl">
            <p><b>WATCH LIST</b></p>
        </div>

        
</body>
</html>